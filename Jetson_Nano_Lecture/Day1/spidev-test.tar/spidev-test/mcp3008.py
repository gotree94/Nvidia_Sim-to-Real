import time
import spidev

spi=spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz=1350000

def analog_read(channel):
    r=spi.xfer2([1,(8+channel)<<4,0]) 
    data=((r[1]&3)<<8)+r[2]
    return data

while True :
    reading = analog_read(0) 
    readingstr = str(reading)
    print('reading : ' , readingstr , 'Voltage:' , reading*3.3/1024 ) 
    time.sleep(1)
